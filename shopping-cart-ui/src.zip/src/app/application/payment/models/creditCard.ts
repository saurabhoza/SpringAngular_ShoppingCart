export class CreditCard{
    nameOnCard?:String;
    cardNumber?: number;
    amount?: number;
    saveCard?: boolean;
    expMonth?: number;
    expYear?: number;
    cvvNo?: number;
    token?: String;
}