export class Payment{
    id?: number;
    amount?: number;
    token?: String;
    saveCard?: boolean;
    status?: string;
    orderId?: string;
    description?: string;
}
