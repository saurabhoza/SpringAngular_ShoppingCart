import { Component, OnInit, OnChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UrlConstants } from '../../../../shared/models/UrlConstants';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {
  addressType: string;

  constructor(private router: ActivatedRoute) {
    this.addressType = UrlConstants.VALUE_SHIPPING;
  }

  ngOnInit() {
    this.router.paramMap.subscribe(params => {
      this.addressType = params.get('addressType');
    });
  }
}
