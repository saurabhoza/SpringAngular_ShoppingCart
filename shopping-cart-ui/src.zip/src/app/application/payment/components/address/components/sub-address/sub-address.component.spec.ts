import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubAddressComponent } from './sub-address.component';

describe('SubAddressComponent', () => {
  let component: SubAddressComponent;
  let fixture: ComponentFixture<SubAddressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubAddressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('SubAddressComponent should create', () => {
    expect(component).toBeTruthy();
  });

  it('Invalid form when all fields are empty', () => {
    expect(component.addressForm.valid).toBeFalsy();
  });

  it('Full name validation', () => {
    let errors = {};
    const fullName = component.addressForm.controls['fullName'];
    expect(fullName).toBeFalsy();
    errors = fullName.errors || {};
    expect(errors['required']).toBeTruthy();
    fullName.setValue('123123');

    errors = fullName.errors || {};
    expect(errors['pattern']).toBeTruthy();
  });


  it('Mobile Number validation with empty value', () => {
    let errors = {};
    const fullName = component.addressForm.controls['fullName'];
    expect(fullName).toBeFalsy();
    errors = fullName.errors || {};
    expect(errors['required']).toBeTruthy();
  });

  it('Mobile Number validation with alphabets', () => {
    let errors = {};
    const fullName = component.addressForm.controls['fullName'];
    fullName.setValue('skdhfkhsdf');
    errors = fullName.errors || {};
    expect(errors['pattern']).toBeTruthy();
  });



  it('Full name validation', () => {
    let errors = {};
    const fullName = component.addressForm.controls['fullName'];
    expect(fullName).toBeFalsy();
    errors = fullName.errors || {};
    expect(errors['required']).toBeTruthy();
    fullName.setValue('123123');

    errors = fullName.errors || {};
    expect(errors['pattern']).toBeTruthy();
  });


});
