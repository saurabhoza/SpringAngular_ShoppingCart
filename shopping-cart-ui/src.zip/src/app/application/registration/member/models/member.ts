export class Member{
    id?:number;
    dob?:string;
    firstName?:string;
    lastName?:string;
    gender?:string;
    address?:string;
    role?:string;
    status?:string;
    emailId?:string;
    contactNumber?:string;
}