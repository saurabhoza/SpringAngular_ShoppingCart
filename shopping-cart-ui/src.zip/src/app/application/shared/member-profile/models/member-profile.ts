export class MemberProfile{
    id?:string;
    dob?:string;
    firstName?:string;
    LastName?:string;
    gender?:string;
    address?:string;
    role?:string;
    status?:string;
    emailId?:string;
    contactNumber?:string;
}