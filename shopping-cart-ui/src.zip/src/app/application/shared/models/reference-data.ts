export class ReferenceData{
    activeTransition?: boolean;
    cartItemCount?:number;
    language?:string;
    languageOptions?:any[];
}