export class HeaderMenu {
    id?: number;
    name?: String;
    url?: String;
    children?: number[];
    parent?: number;
    isRoot?: string;
}