export class Login {
    userId?: number;
    userName?: string;
    memberId?: number;
    password?: string;
    token?: string;
    errMsg?: string;
}