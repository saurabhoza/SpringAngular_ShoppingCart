export class Product{
    id?:number;    
    name?:string;
    price?:number;
    quantityAvailable:number;
    thumbnailURL:string;        
}