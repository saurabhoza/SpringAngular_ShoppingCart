export class ProductDetail{
    id?:number;    
    name?:string;
    description?:string;
    mrp?:number;
    sellingPrice?:number;
    thumbnailURL?:string;
    seller?:string;    
    availableQuantity?:number;    
}