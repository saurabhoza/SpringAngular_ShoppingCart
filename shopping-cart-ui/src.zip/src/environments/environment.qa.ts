export const environment = {
    production: false,
    isDebugMode: true,
    envName: 'qa',
    serviceContext: 'http://epinpunw0037:8080/shoppingcartservice_beta/'
};