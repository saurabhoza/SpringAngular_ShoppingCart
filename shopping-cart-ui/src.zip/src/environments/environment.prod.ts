export const environment = {
  production: true,
  isDebugMode: false,
  envName: 'prod',
  serviceContext: 'prodUrl'
};
